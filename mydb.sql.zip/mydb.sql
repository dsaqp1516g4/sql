DROP DATABASE IF EXISTS mydb;
CREATE DATABASE mydb;
USE mydb;

CREATE TABLE users
(
userid BINARY(16) NOT NULL,
usernam varchar(255) NOT NULL,
pass BINARY(16) NOT NULL,
email VARCHAR(255) NOT NULL,
listsid VARCHAR(255) NOT NULL,
adsid VARCHAR(255) NOT NULL,
FOREIGN KEY (lists) REFERENCES lists(listsid),
FOREIGN KEY (adsid) REFERENCES ads(adsid),
PRIMARY KEY (userid)
));

CREATE TABLE ads
(
userid BINARY(16) NOT NULL,
adsid INT(255) NOT NULL,
adscont VARCHAR(255) NOT NULL,

type INT(10) NOT NULL,
FOREIGN KEY (userid) REFERENCES users(userid),
FOREIGN KEY (adscont) REFERENCES adscont(adscont),
PRIMARY KEY (adsid)   
));

CREATE TABLE adscont
(
adsid INT(255) NOT NULL,
adscont VARCHAR(255) NOT NULL,
opciones VARCHAR(255) NOT NULL,
lists VARCHAR(255) NOT NULL,
FOREIGN KEY (adsid) REFERENCES ads(adsid),
FOREIGN KEY (lists) REFERENCES lists(lists),
PRIMARY KEY (adscont)   
);


CREATE TABLE lists
(
listsid INT(255) NOT NULL,
lists VARCHAR(255) NOT NULL,
PRIMARY KEY (lists)   
);


